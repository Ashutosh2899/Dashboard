import { Component } from '@angular/core';

@Component({
    selector: 'app-search-form',
    templateUrl: './search-form.component.html',
    styleUrls: ['./search-form.component.css'],
    standalone: false
})
export class SearchFormComponent {
  submit() {
    // Implement submit logic
  }

  cancel() {
    // Implement cancel logic
  }
}
